## 🔴 TLP:RED – Shai-Hulud (Internal Use Only)

- Classification: TLP:RED
- Reviewed by: CTI Lead, Legal, Comms
- IOC Bundle: [link]
- Artifact Status: In Review