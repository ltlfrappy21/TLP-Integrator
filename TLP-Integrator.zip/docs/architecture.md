# Architecture Overview

This module automates TLP-labeled intelligence synchronization across Hive, MISP, Cortex, and Notion using secure OIDC-authenticated GitHub Actions pipelines.