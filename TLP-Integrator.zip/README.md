# TLP-Integrator

An open-source integration module to synchronize TLP-classified CTI artifacts across TheHive, MISP, Cortex, Notion, and secure CI/CD pipelines.